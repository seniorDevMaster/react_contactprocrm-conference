const config = {
    path: 'https://cdn.jsdelivr.net/emojione/assets/3.0/png',
    css: false,
    native: false,
    replace: 'unified',
    set: 'google',
    resolution: 64
};

export default config;