import React, { useState } from "react";

function Blank(props) {
    
    return <div className='Blank'>
            
            <h1> 404 Page Error!</h1>
        </div>;
}
export default Blank;
