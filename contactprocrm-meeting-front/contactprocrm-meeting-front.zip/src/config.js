export const API_URL = process.env.NODE_ENV === 'production'
  ? 'https://chat.contactprocrm.com'
  : 'http://localhost:3222'
